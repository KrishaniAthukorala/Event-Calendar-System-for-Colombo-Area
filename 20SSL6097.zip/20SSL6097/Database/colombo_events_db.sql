-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2026 at 11:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `colombo_events_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'krisha', 'krisha1234');

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE `artists` (
  `artist_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `photo_url` varchar(255) NOT NULL,
  `upcoming_event` varchar(100) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(20) NOT NULL,
  `event_venue` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artists`
--

INSERT INTO `artists` (`artist_id`, `name`, `description`, `category`, `photo_url`, `upcoming_event`, `event_date`, `event_time`, `event_venue`) VALUES
(1, 'Kanchana Anuradhi', 'Singer, performer, musician, and lyricist', 'Music', 'images/kanchana.jpg', 'The Acoustic Night', '2026-02-15', '7:00 PM', 'Waters Edge'),
(2, 'Kavindu Madushan\r\n', 'Model and Dancer\r\n', 'Dancing', 'images/kavindu.jpg', 'Dancing Waves', '2026-03-20', '6:00 PM', 'BMICH'),
(3, 'Malinda Jayasinghe', 'Visual artist and art curator', 'Art', 'images/malinda.jpg', 'Canvas Dreams', '2026-03-10', '5:00 PM', 'Colombo Art Gallery'),
(4, 'Duleeka Marapana', 'Stage actress and drama director', 'Drama', 'images/dulika.jpg', 'Curtain Call', '2026-01-25', '7:00 PM', 'Lionel Wendt Theatre'),
(7, 'Lahiru Perera', 'Singer, Musician and Music producer', 'Music', 'images/lahiru.jpg', 'Aala Hendewa', '2026-02-14', '6.30PM', 'BMICH'),
(8, 'Nadeemal Perera', 'Singer', 'Music', 'images/nadeemal.jpg', 'Nethu Dehen', '2026-01-10', '6.30PM', 'BMICH'),
(9, 'Sashika Nisansala', 'Singer and Playback singer', 'Music', 'images/sashika.jpg', 'Kaatrin Mozhi', '2026-01-17', '5.00PM', 'Port City'),
(10, ' Keerthi Pasquel', 'Pop musician and Composer', 'Music', 'images/keerthi.jpg', 'Sonduru Bambarek', '2026-01-25', '7.00PM', 'Nelum Pokuna '),
(11, 'Chandana Wickramasinghe', 'Professional Dancer', 'Dancing', 'images/chandana.jpg', 'Chaarya', '2026-03-20', '8.00PM', 'Nelum Pokuna '),
(12, 'Channa Wijewardena ', 'Professional Dancer & Choreographer', 'Dancing', 'images/channa.jpg', 'Sithijayen aarak', '2026-01-22', '7.00PM', 'Nelum Pokuna '),
(13, 'Kevin Nugara', 'Professional Latin American and Ballroom Dance Teacher', 'Dancing', 'images/kevin.jpg', 'Latin Feet', '2026-03-22', '8.00PM', 'Kingsbury Hotel Colombo'),
(14, 'Saara Abeywardane ', 'Pop mixing dancing show', 'Dancing', 'images/saara.jpg', 'Step up', '2026-02-10', '8.00PM', 'Cinnamon Grand Colombo'),
(15, 'Anoma Wijewardene', ' Designer and Artist', 'Art', 'images/anoma.jpg', 'Art Rate', '2026-03-27', '8.00PM', 'Viharamahadevi Park '),
(16, ' Master Potter Ajith Mohan Perera', 'Prominent Potter', 'Art', 'images/ajith.jpg', 'Kalaya', '2026-02-09', '9.30AM', 'Havelock City Mall'),
(17, 'Senaka Senanayake', 'Painter', 'Art', 'images/senaka.jpg', 'Gallerias', '2026-01-24', '9.30AM', 'Kingsbury Hotel Colombo'),
(18, 'Jagath Weerasinghe ', 'Artist and Archeologist', 'Art', 'images/jagath.jpg', 'Brush Scope', '2026-02-15', '9.30AM', 'Waters Edge'),
(19, 'Niroshan Wijesinghe', 'Actor and Writer', 'Drama', 'images/niroshan.jpg', 'Katu Aththak', '2026-03-29', '6.30PM', 'Tower Hall '),
(20, 'Sampath Jayaweera', 'Actor', 'Drama', 'images/sampath.jpg', 'Situ Madura', '2026-02-21', '6.30PM', 'Bishop’s College Auditorium'),
(21, 'Dharmapriya Dias', 'Actor, Set designer, Choreographer, Teacher', 'Drama', 'images/dharmapriya.jpg', 'Mama Newei Kenek', '2026-02-25', '3.30PM', 'Sugathadasa Indoor Stadium'),
(22, 'Madani Malwaththa', 'Prominent Actress and Model', 'Drama', 'images/madani.jpg', 'Katu Pokuru', '2026-03-12', '3.30PM', 'Tower Hall ');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `organizer_name` varchar(100) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_location` varchar(150) NOT NULL,
  `ticket_booking_place` varchar(255) NOT NULL,
  `event_category` varchar(50) NOT NULL,
  `event_start_date` datetime NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `mobile_number` varchar(100) NOT NULL,
  `event_remark` text NOT NULL,
  `vip_count` int(11) DEFAULT NULL,
  `vip_price` decimal(10,2) DEFAULT NULL,
  `regular_count` int(11) DEFAULT NULL,
  `regular_price` decimal(10,2) DEFAULT NULL,
  `standing_count` int(11) DEFAULT NULL,
  `standing_price` decimal(10,2) DEFAULT NULL,
  `is_free_event` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`organizer_name`, `event_name`, `event_location`, `ticket_booking_place`, `event_category`, `event_start_date`, `contact_email`, `mobile_number`, `event_remark`, `vip_count`, `vip_price`, `regular_count`, `regular_price`, `standing_count`, `standing_price`, `is_free_event`) VALUES
('Sanka Athauda', 'Kaatrin Mozhi', 'Port City', 'On-site', 'Music', '2026-01-17 17:00:00', 'sanka@gmail.com', '0781256852', 'Modern music concert', 5, 5500.00, 10, 4000.00, 10, 3500.00, 0),
('Kasun Manuranaga', 'Nethu Dehen', 'BMICH', 'Musaeus College', 'Music', '2026-01-10 18:30:00', 'sanka@gmail.com', '0774589456', 'Combined music concert', 14, 4000.00, 18, 3000.00, 23, 2500.00, 0),
('Priyantha Samaraweera', 'Anuradha Paudwal Live in Colombo', 'Nelum Pokuna', 'On-site or online', 'Music', '2026-01-23 18:30:00', 'priyantha@gmail.com', '0714589456', 'Bollywood concert', 14, 7000.00, 13, 6000.00, 20, 5000.00, 0),
('Akash Weerasekara', 'K S CHITHRA Live in concert', 'Sugathadasa Indoor Stadium', 'On-site', 'Music', '2026-02-07 19:00:00', 'akash@gmail.com', '0764589123', 'Tamil Concert', 14, 6000.00, 19, 5500.00, 23, 5000.00, 0),
('Sithum Disanayake', 'Sonduru Bambarek', 'Nelum Pokuna ', 'Kapruka', 'Music', '2026-01-25 19:00:00', 'sithumdisanayake@gmail.com', '0718945741', 'Keerthi Pasquel', 14, 6000.00, 18, 5000.00, 23, 3000.00, 0),
('Rukshan Kodikara', 'Aala Hendewa', 'BMICH', 'TicketsLK, On site', 'Music', '2026-02-14 18:30:00', 'rukshankodikara@gmail.com', '0789685456', 'Valentine Music Concert', 10, 8000.00, 13, 7000.00, 13, 6000.00, 0),
('Dilantha Kannangara', 'Rugby Power', 'R. Premadasa Stadium', '', 'Sports', '2026-02-09 09:00:00', 'dilanthakannangara@gmail.com', '0768945753', 'All-Island Rugby Match', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Hirun Aththanayake', 'Flash Car', 'Colombo Super Cross Race Track', 'TicketsLK, On Site', 'Sports', '2026-02-17 09:00:00', 'hirunaththanayake@gmail.com', '0785678123', 'Car race event', 0, 15000.00, 0, 10000.00, 0, 7000.00, 0),
('Sampath Ekanayake', 'Volley Battle', 'Galle Face Green', '', 'Sports', '2026-01-13 09:00:00', 'sampathekanayake@gmail.com', '0758945852', 'Beach Volleyball Battle', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Srimal Wijesinghe', 'FootSplash', 'R.Premadasa Stadium', 'On Site', 'Sports', '2026-03-10 09:00:00', 'srimalwijesinghe@gmail.com', '0767452456', 'Football match ', 13, 5000.00, 18, 4000.00, 22, 3000.00, 0),
('Yasapala Amarathunga', 'Kelaniya Duruthu Perahera', 'Kelaniya Rajamaha Viharaya', '', 'Arts', '2026-02-12 19:30:00', 'yasapalaamarathunga@gmail.com', '0784523753', 'Annual Traditional Kelaniya Rajamaha Viharaya Perahera', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Sakura Aththanayake', 'Saakuur', 'Viharamahadevi Park Open Air Theatre', 'On-site', 'Arts', '2026-03-11 10:32:00', 'sakuraaththanayake@gmail.com', '0751256456', 'Sakura Aththanayake\' performance concert', 16, 3500.00, 10, 2500.00, 19, 1000.00, 0),
('Yoshya Amaranayake', 'Experience The Spirit', 'Independence Square', '', 'Arts', '2026-02-02 19:30:00', 'yoshyaamaranayake@gmail.com', '0764589128', '', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Asanga Disasekara', 'Fire Sparkles', 'Galle Face Green', '', 'Arts', '2026-02-27 20:00:00', 'asangadisasekara@gmail.com', '0758978456', 'Fireworks Show', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Saumya Sendanayake', 'Agro Tech', 'Cinnamon Grand Colombo', '', 'Business', '2026-01-28 09:00:00', 'saumyasendanayake@gmail.com', '0752345785', 'New technological products related to agriculture', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Takeshi Tuwan', 'Art of Ikebana', 'BMICH', 'Kapruka, On Site', 'Arts', '2026-03-18 09:30:00', 'takeshituwan@gmail.com', '0782890123', 'Japanese traditional floral design show', NULL, NULL, NULL, NULL, 0, 1000.00, 0),
('Sanath Balapitiya', 'Dream Archi', 'Cinnamon Lakeside Colombo', 'On-site', 'Business', '2026-02-22 09:00:00', 'sanathbalapitiya@gmail.com', '0785625147', 'Introduce new design ideas for houses', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Daran Rathnayake', 'Furni Court', 'Waters Edge', '', 'Business', '2026-03-14 09:00:00', 'daranrathnayake@gmail.com', '0751223563', 'Introduce new furniture designs for other makers', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Ishikiya Andro', 'Parfum', 'Shangri-La Hotel Colombo', 'Kapruka, On Site', 'Business', '2026-02-04 09:00:00', 'ishikiyaandro@gmail.com', '0781256851', 'Introducing new products in various perfume brands', NULL, NULL, NULL, NULL, 105, 1000.00, 0),
('Priyantha Athukorala', 'Mustang Splash', 'R. Premadasa Stadium', 'On-site', 'Other', '2026-01-15 09:00:00', 'priyanthaathukorala@gmail.com', '0764589125', 'Different type of mustang car show', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Karthik Adikaram', 'Old Is Gold', 'Viharamahadevi Park ', 'Musaeus College, On Site', 'Other', '2026-03-24 09:00:00', 'karthikadikaram@gmail.com', '0774589451', 'Antique auction', NULL, NULL, NULL, NULL, 150, 200.00, 0),
('Ramal Serasinghe', 'Motor Co', 'BMICH', 'On-site', 'Business', '2026-03-22 09:00:00', 'ramalserasinghe@gmail.com', '0758952123', 'Introduce new vehicle parts', NULL, NULL, NULL, NULL, 0, 1000.00, 0),
('Priyanath Somasundara', 'Old Note', 'One Galle Face Mall', '', 'Other', '2026-03-27 09:00:00', 'priyanathsomasundara@gmail.com', '0714589458', 'Collect old notes and pay for their value', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Ranga Athauda', 'Animal Land', 'Viharamahadevi Park ', 'On-site', 'Other', '2026-03-02 09:30:00', 'rangaathauda@gmail.com', '0712457890', 'Animal Carnival Show', NULL, NULL, NULL, NULL, NULL, NULL, 1),
('Ashakya Sendanayake', 'Caki Picnic', 'Viharamahadevi Park ', '', 'Other', '2026-03-06 09:00:00', 'ashakyasendanayake@gmail.com', '0781256850', 'Various flaovors and design cake picnic', NULL, NULL, NULL, NULL, 50, 500.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `location_name`, `latitude`, `longitude`, `address`) VALUES
(1, 'BMICH', 6.9016, 79.8612, 'Bauddhaloka Mawatha, Colombo 07'),
(2, 'Nelum Pokuna Mahinda Rajapaksa Theatre', 6.9147, 79.8611, 'Green Path, Colombo 07'),
(3, 'Colombo City Centre', 6.9164, 79.8489, 'Sir James Pieris Mawatha, Colombo 02'),
(4, 'One Galle Face Mall', 6.9248, 79.8449, 'Centre Road, Colombo 01'),
(5, 'Port City Colombo', 6.933, 79.8373, 'Colombo 01'),
(6, 'Waters Edge', 6.905, 79.947, 'Battaramulla'),
(7, 'Sugathadasa Indoor Stadium', 6.9447, 79.865, 'Sirimavo Bandaranaike Mawatha, Colombo 14'),
(8, 'Colombo Racecourse Grounds', 6.9061, 79.8616, 'Reid Avenue, Colombo 07'),
(9, 'Viharamahadevi Park Open Air Theatre', 6.9158, 79.8615, 'Colombo 07'),
(10, 'Independence Square', 6.9022, 79.8617, 'Independence Avenue, Colombo 07'),
(11, 'Galle Face Green', 6.924, 79.8443, 'Galle Road, Colombo 03'),
(12, 'Bishop’s College Auditorium', 6.9109, 79.8537, 'Colombo 03'),
(13, 'Royal MAS Arena (Royal College)', 6.9065, 79.8611, 'Colombo 07'),
(14, 'Sri Lanka Exhibition and Convention Centre (SLECC)', 6.936, 79.8483, 'D R Wijewardena Mawatha, Colombo 10'),
(15, 'Colombo Public Library Auditorium', 6.9156, 79.8571, 'Colombo 07'),
(16, 'Nelum Pokuna Outdoor Amphitheatre', 6.9172, 79.8626, 'Colombo 07'),
(17, 'Havelock City Mall', 6.8879, 79.8657, 'Havelock Road, Colombo 05'),
(19, 'Bellanwila Temple Grounds', 6.8475, 79.9026, 'Bellanwila, Colombo district'),
(20, 'Dehiwala Municipal Grounds', 6.853, 79.8651, 'Dehiwala'),
(21, 'Mount Lavinia Hotel Beach Area', 6.832, 79.8631, 'Mount Lavinia'),
(22, 'Taj Samudra Colombo', 6.9258, 79.8463, 'Galle Face Centre Road, Colombo 03'),
(23, 'Shangri-La Hotel Colombo', 6.927, 79.8445, 'Galle Face, Colombo 02'),
(24, 'Cinnamon Grand Colombo', 6.9275, 79.8472, 'Colombo 03'),
(25, 'Cinnamon Lakeside Colombo', 6.9273, 79.8501, 'Sri Wickrama Rajasinghe Mawatha, Colombo 02'),
(26, 'Kingsbury Hotel Colombo', 6.9338, 79.8424, 'Janadhipathi Mawatha, Colombo 01'),
(29, 'R. Premadasa Stadium', 6.93997, 79.87229, 'Khettarama Temple Rd, Colombo 01000'),
(30, 'Colombo Lotus Tower', 6.92703, 79.85828, '320 McCallum Rd, Colombo 01000');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `review_text` text NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `username`, `review_text`, `rating`, `created_at`) VALUES
(2, 'Ashani Athukorala', 'Super', 5, '2025-11-29 14:25:23'),
(3, 'Kasun Manuranga', 'Perfect ', 4, '2025-11-29 16:30:52'),
(4, 'Champika Walpola', 'Good', 3, '2025-11-29 16:38:57'),
(5, 'Lasitha Rukshan', 'Perfect calendar', 4, '2025-11-30 16:15:10'),
(6, 'Senuli Dihansa', 'Easy to use', 5, '2025-12-09 18:28:59'),
(7, 'Anuththara Rajapaksha', 'Helpful ', 5, '2026-01-07 10:27:53');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_bookings`
--

CREATE TABLE `ticket_bookings` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `booking_email` varchar(100) DEFAULT NULL,
  `booking_phone` int(20) DEFAULT NULL,
  `event_name` varchar(100) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` time DEFAULT NULL,
  `ticket_category` varchar(50) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_bookings`
--

INSERT INTO `ticket_bookings` (`id`, `full_name`, `booking_email`, `booking_phone`, `event_name`, `event_date`, `event_time`, `ticket_category`, `unit_price`, `quantity`, `total_amount`) VALUES
(123, 'Saara Wijewardana', 'saarawijewardana597@gmail.com', 714556780, 'Flash Car', '2026-02-17', '09:00:00', 'regular', 10000.00, 1, 10000.00),
(124, 'Saara Wijewardana', 'saarawijewardana597@gmail.com', 714556780, 'Flash Car', '2026-02-17', '09:00:00', 'standing', 7000.00, 1, 7000.00),
(125, 'Kasun Manuranga', 'kasunmanuranga@gmail.com', 755689780, 'Flash Car', '2026-02-17', '09:00:00', 'vip', 15000.00, 2, 30000.00),
(126, 'Ashani Athukorala', 'ashaniathukorala@gmail.com', 714556781, 'Art of Ikebana', '2026-03-18', '09:30:00', 'standing', 1000.00, 1, 1000.00),
(127, 'Adithya Perera', 'adithyaperera@gmail.com', 714589741, 'Motor Co', '2026-03-22', '09:00:00', 'standing', 1000.00, 1, 1000.00),
(128, 'Kaveesha Walpola', 'kaveeshawalpola@gmail.com', 784512789, 'Saakuur', '2026-03-11', '10:30:00', 'regular', 2500.00, 1, 2500.00),
(129, 'Kaveesha Walpola', 'kaveeshawalpola@gmail.com', 784512789, 'Saakuur', '2026-03-11', '10:30:00', 'standing', 1000.00, 2, 2000.00),
(130, 'Gangul Aththanayake', 'gangulaththanayake@gmail.com', 718552456, 'Anuradha Paudwal Live in Colombo', '2026-01-23', '18:30:00', 'vip', 7000.00, 1, 7000.00),
(131, 'Gangul Aththanayake', 'gangulaththanayake@gmail.com', 718552456, 'Anuradha Paudwal Live in Colombo', '2026-01-23', '18:30:00', 'regular', 6000.00, 2, 12000.00),
(132, 'Akram Sahid', 'akashsahid@gmail.com', 765689123, 'K S CHITHRA Live in concert', '2026-02-07', '19:00:00', 'vip', 6000.00, 1, 6000.00),
(133, 'Akram Sahid', 'akashsahid@gmail.com', 765689123, 'K S CHITHRA Live in concert', '2026-02-07', '19:00:00', 'regular', 5500.00, 1, 5500.00),
(134, 'Akram Sahid', 'akashsahid@gmail.com', 765689123, 'K S CHITHRA Live in concert', '2026-02-07', '19:00:00', 'standing', 5000.00, 2, 10000.00),
(135, 'Sonya Disasekara', 'sonyadisasekra@gmail.com', 752356789, 'Nethu Dehen', '2026-01-10', '18:30:00', 'vip', 4000.00, 1, 4000.00),
(136, 'Sonya Disasekara', 'sonyadisasekra@gmail.com', 752356789, 'Nethu Dehen', '2026-01-10', '18:30:00', 'regular', 3000.00, 2, 6000.00),
(137, 'Sonya Disasekara', 'sonyadisasekra@gmail.com', 752356789, 'Nethu Dehen', '2026-01-10', '18:30:00', 'standing', 2500.00, 2, 5000.00),
(138, 'Mandira Kobbagala', 'mandirakobbagala@gmail.com', 713929681, 'Aala Hendewa', '2026-02-14', '20:30:00', 'regular', 7000.00, 2, 14000.00),
(139, 'Mandira Kobbagala', 'mandirakobbagala@gmail.com', 713929681, 'Aala Hendewa', '2026-02-14', '20:30:00', 'standing', 6000.00, 2, 12000.00),
(140, 'Anuththara Adikari', 'anuththaraadikari@gmail.com', 757856123, 'Sonduru Bambarek', '2026-01-25', '19:00:00', 'vip', 6000.00, 1, 6000.00),
(141, 'Anuththara Adikari', 'anuththaraadikari@gmail.com', 757856123, 'Sonduru Bambarek', '2026-01-25', '19:00:00', 'regular', 5000.00, 2, 10000.00),
(142, 'Anuththara Adikari', 'anuththaraadikari@gmail.com', 757856123, 'Sonduru Bambarek', '2026-01-25', '19:00:00', 'standing', 3000.00, 2, 6000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`artist_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_bookings`
--
ALTER TABLE `ticket_bookings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `artists`
--
ALTER TABLE `artists`
  MODIFY `artist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ticket_bookings`
--
ALTER TABLE `ticket_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
