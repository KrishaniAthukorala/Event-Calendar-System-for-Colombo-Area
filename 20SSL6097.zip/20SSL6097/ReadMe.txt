xampp
Apache Tomcat v10.1
mysql-connector-j-9.3.0.jar
Eclipse IDE for Enterprise Java and Web Developers
Admin username-krisha
Admin password-krisha1234
Admin panel link-http://localhost:8080/EventCalendar/admin_login.jsp
Dashboard panel link-http://localhost:8080/EventCalendar/IndexServlet
Event panel-http://localhost:8080/EventCalendar/loadEvents
Artist panel-http://localhost:8080/EventCalendar/loadArtists
Ticket panel-http://localhost:8080/EventCalendar/ticket_booking.jsp
Contact Us panel-http://localhost:8080/EventCalendar/contact_us.jsp